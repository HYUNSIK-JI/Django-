from django import forms
from django.contrib import auth
from django.contrib.auth.forms import UserCreationForm,AuthenticationForm
from django.contrib.auth import password_validation
from .models import CommunityUser,UserManager
from django.core.exceptions import ValidationError

class SignupForm(UserCreationForm):
    class Meta(UserCreationForm.Meta):
        model = CommunityUser
        fields = ['nickname','email','password1','password2',]