from django.shortcuts import render,redirect,get_object_or_404
from .models import Article,Comment
from .forms import ArticleForm,CommentForm
from django.views.decorators.http import require_POST
from django.contrib.auth.decorators import login_required


def index(request):
    all = Article.objects.all().order_by('id')
    context={
        "v":all
    }
    return render(request, 'articles/index.html', context)

@login_required()
def create(request):
    if request.method == "POST":
        Article_Form = ArticleForm(request.POST)
        if Article_Form.is_valid():
            post = Article_Form.save(commit=False)
            post.user = request.user
            post.save()
            return redirect("articles:index")
    else:
        Article_Form = ArticleForm()
    return render(request, "articles/create.html",{"Article_Form":Article_Form})

@login_required()
def detail(request, pk):
    v = Article.objects.get(pk=pk)
    article = get_object_or_404(Article, pk=pk)
    comments = Comment.objects.filter(article_id=pk)
    comment_form = CommentForm(request.POST)
    context = {
            "v": v,
            "all": article.like_users.all(),
            "count": article.like_users.count,
            "comment_form":comment_form,
            "comments":comments,
    }
    return render(request, "articles/detail.html", context)

@login_required()
def delete(request, pk):
    Article.objects.get(pk=pk).delete()
    return redirect("articles:index")

@login_required()
def update(request, pk):
    k = Article.objects.get(pk=pk)
    if request.method == "POST":
        Article_Form = ArticleForm(request.POST, instance=k)
        if Article_Form.is_valid():
            Article_Form.save()
            return redirect("articles:index")
    else:
        Article_Form = ArticleForm(instance=k)
    return render(request, "articles/update.html",{"Article_Form":Article_Form ,"v":k})

@login_required()
def like(request, pk):
    article = get_object_or_404(Article, pk=pk)
    if article.like_users.filter(id=request.user.pk).exists():
        article.like_users.remove(request.user)
    else:
        article.like_users.add(request.user)
    return redirect('articles:detail', pk)

@require_POST
def comments_create(request, pk):
    if request.user.is_authenticated:
        article = get_object_or_404(Article, pk=pk)
        comment_form = CommentForm(request.POST)
        if comment_form.is_valid():
            comment = comment_form.save(commit=False)
            comment.article = article
            comment.user = request.user
            comment.save()
        return redirect('articles:detail', article.pk)
    return redirect('accounts:login')


@require_POST
def comments_delete(request, article_pk, comment_pk):
    if request.user.is_authenticated:
        print(1)
        comment = Comment.objects.get(pk=comment_pk)  
        if request.user == comment.user:
            print(2)
            comment.delete()
    return redirect('articles:detail', article_pk)