import requests
from bs4 import BeautifulSoup

def naver_news_search(keyword, num_page) :
    result = []
    for s in range(num_page) :
        # 네이버 뉴스
        url = 'http://search.naver.com/search.naver?where=news'
        params = {'query' : keyword, 'start' : (10 * s + 1)}
        res = requests.get(url, params)
        if res.status_code != 200 :
            print('HTTP Status Code:', res.status_code)
            continue
        # 네이버 뉴스 페이지
        print(f'--- page {s + 1} ---')
        html = res.text.strip()
        # soup = BeautifulSoup(html, 'html5lib')
        soup = BeautifulSoup(res.text, "html.parser")
        img = soup.find_all('img')
        # 네이버 뉴스 한 페이지 당 10개의 기사
        for i in range(1, 11) :
            press_selector = f'ul.list_news > li:nth-of-type({i}) div.info_group > a:nth-of-type(1)'
            press_names = soup.select_one(press_selector)
            if press_names :
                # 뉴스 언론사
                # print(press_names.text.replace('언론사 선정', ''))
                press_name_txt = press_names.text.replace('언론사 선정', '')
                print(press_name_txt)

            naver_link_sel = f'ul.list_news > li:nth-of-type({i}) div.info_group > a:nth-of-type(2)'
            naver_link = soup.select_one(naver_link_sel)
            if naver_link :
                # 뉴스 url
                print(naver_link['href'])

            title_selector = f'ul.list_news > li:nth-of-type({i}) div.news_area > a'
            title = soup.select_one(title_selector)
            # 뉴스 타이틀
            print(title['href'])
            print(title.text.strip())
            image_url_selector = f'ul.list_news > li:nth-of-type({i}) div.news_area > a'
            image_url = soup.select_one(image_url_selector)
            print(image_url_selector)
            print(image_url)
            result.append({
                'press_name':press_name_txt,
                'title':title.text.strip(),
                'original_link':title['href'],
                # 'image':image_url['src']
            })
            print()
            print(result)
    return result
# naver_news_search("자페", 1)