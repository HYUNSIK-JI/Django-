from django.shortcuts import render, redirect
from .forms import UsersForm
from django.contrib.auth import get_user_model
from django.contrib.auth.hashers import make_password,check_password
from django.contrib.auth.forms import AuthenticationForm
from django.contrib import auth
from django.contrib.auth import login as auth_login
from django.contrib.auth import logout as auth_logout
# Create your views here.

def index(request):
    all = Article.objects.all().order_by('id')
    context={
        "v":all
    }
    return render(request, 'articles/index.html', context)
def login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, request.POST)
        if form.is_valid():
            auth_login(request, form.get_user())
        return redirect('accounts:index')
    
    else:
        form = AuthenticationForm()
    
    return render(request, 'accounts/login.html', {'form' : form})
def logout(request):
    auth_logout(request)
    return redirect('accounts:index')

def signup(request):
    if request.method == "POST":
        form = UsersForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("accounts:index")
    else:
        form = UsersForm()
    context ={
        'form':form
    }
    return render(request,"accounts/signup.html", context)