from importlib.resources import contents
import re
from django.shortcuts import render, redirect
from .models import Review,User1
from django.http import HttpResponse
from django.contrib.auth.hashers import make_password,check_password
from django.views.decorators.csrf import csrf_exempt
from django.db.models import Q


def index(request):
    k = Review.objects.all()
    context = {"c": k}
    return render(request, "Pair1/index.html", context)


def home(request):
    k = Review.objects.all()
    return redirect("Pair1:index")


def index1(request, pk):
    k = Review.objects.all()
    return redirect("Pair1:index")


def new(request):
    return render(request, "Pair1/new.html")


def create(request):
    k = request.GET
    v = [k[i] for i in k]
    Review.objects.create(title=v[0], content=v[1])
    return redirect("Pair1:index")


def detail(request, pk):
    k = Review.objects.get(pk=pk)
    context = {"c": k}
    return render(request, "Pair1/detail.html", context)
def details(request):
    k = Review.objects.latest('pk')
    context = {
        "c":k
    }
    return render(request,"Pair1/details.html",context)

def delete(request, pk):
    Review.objects.get(pk=pk).delete()
    return redirect("Pair1:index")


def edit(request, pk):
    k = Review.objects.get(pk=pk)
    context = {"c": k}
    return render(request, "Pair1/edit.html", context)


def update(request, pk):
    r = Review.objects.get(pk=pk)

    title = request.GET.get("title")
    content = request.GET.get("content")

    r.title = title
    r.content = content

    r.save()
    return redirect("Pair1:detail", r.pk)
def register(request):   #회원가입 페이지를 보여주기 위한 함수
    if request.method == "GET":
        return render(request, "Pair1/register.html")

    elif request.method == "POST":
        username = request.POST.get('username', None)  #딕셔너리형태
        password = request.POST.get('password', None)
        re_password = request.POST.get('re_password',None)
        res_data = {} 
        if not (username and password and re_password) :
            res_data['error'] = "모든 값을 입력해야 합니다."
        if password != re_password :
            # return HttpResponse('비밀번호가 다릅니다.')
            res_data['error'] = '비밀번호가 다릅니다.'
        else :
            user = User1(username=username, password=make_password(password))
            user.save()
        return render(request, "Pair1/register.html", res_data) #register를 요청받으면 register.html 로 응답.
def logins(request):
    response_data = {}

    if request.method == "GET" :
        return render(request, 'Pair1/logins.html')

    elif request.method == "POST":
        login_username = request.POST.get('username', None)
        login_password = request.POST.get('password', None)


        if not (login_username and login_password):
            response_data['error']="아이디와 비밀번호를 모두 입력해주세요."
        else : 
            myuser = User1.objects.get(username=login_username) 
            #db에서 꺼내는 명령. Post로 받아온 username으로 , db의 username을 꺼내온다.
            if check_password(login_password, myuser.password):
                request.session['user'] = myuser.id
                request.session['username'] = myuser.username
                #세션도 딕셔너리 변수 사용과 똑같이 사용하면 된다.
                #세션 user라는 key에 방금 로그인한 id를 저장한것.
                return redirect('/')
            else:
                response_data['error'] = "비밀번호를 틀렸습니다."

        return render(request, 'Pair1/logins.html', response_data)
def homes(request):
    user_id = request.session.get('user')
    if user_id:
        myuser_info = User1.objects.get(pk=user_id)  #pk : primary key
        return HttpResponse(myuser_info.username)   # 로그인을 했다면, username 출력

    return HttpResponse('로그인을 해주세요.') #session에 user가 없다면, (로그인을 안했다면)
def logout(request):
    request.session.pop('user')
    request.session.pop('username')
    return redirect('/')
def search(request):
    content_list = Review.objects.all()
    search = request.GET.get('search','')
    # paginator = Paginator(search_list,5)
    # page = request.GET.get('page','')
    # posts = paginator.get_page(page)
    # board = Board.objects.all()

    if search:
        search_list = content_list.filter(
            Q(title__icontains = search) | #제목
            Q(content__icontains = search) #내용
            )
        return render(request, 'Pair1/search.html',{'search':search_list})
    else:
        return render(request,'Pair1/searchfail.html')
def searchfail(request):
    return render(request,'Pair1/searchfail.html')