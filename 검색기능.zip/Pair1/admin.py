from django.contrib import admin
from .models import Review
from .models import User1
# Register your models here.

admin.site.register(Review)

class UserAdmin(admin.ModelAdmin) :
    list_display = ('username', 'password')


admin.site.register(User1, UserAdmin) #site에 등록